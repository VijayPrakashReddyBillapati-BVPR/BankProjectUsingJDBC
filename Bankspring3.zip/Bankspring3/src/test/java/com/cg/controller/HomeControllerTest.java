package com.cg.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.web.servlet.MockMvc;
//@RunWith(SpringRunner.class)
//@WebMvcTest(HomeController.class) 

class HomeControllerTest {
	
//	
//	
//	private MockMvc mockMvc; 
//	 @Test
//	 public void testHomePage() throws Exception {
//	 mockMvc.perform(get("/")) 
//	 .andExpect(content().string( 	
//	 containsString("Loading...")));
//	 }
//
//	
//	
//	
//	
//
//	@Test
//	void testStart() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testRegister() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testLogin() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testDeposit() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testWithdraw() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testShowBalance() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testFundTransfer() {
//		fail("Not yet implemented");
//	}

}
